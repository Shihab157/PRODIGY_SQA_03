# =============================================================
# config.py — Central configuration for the test suite
# Project  : PRODIGY_SQA_03 — Automated Login Test Suite
# Website  : https://www.demoblaze.com
# =============================================================

# ── Base URL ──────────────────────────────────────────────────
BASE_URL = "https://www.demoblaze.com"

# ── Browser settings ─────────────────────────────────────────
# Options: "chrome" | "firefox" | "edge"
BROWSER = "chrome"
HEADLESS = False          # Set True to run without opening a browser window
IMPLICIT_WAIT = 10        # seconds
PAGE_LOAD_TIMEOUT = 30    # seconds

# ── Test credentials ─────────────────────────────────────────
# NOTE: Register this account on demoblaze.com before running tests.
# Go to https://www.demoblaze.com → Sign up → create the account below.
VALID_USERNAME = "prodigy_test_user"
VALID_PASSWORD = "Test@1234"

# ── Invalid / negative credentials ───────────────────────────
WRONG_PASSWORD     = "WrongPass@999"
WRONG_USERNAME     = "nonexistent_xyz_user"
WRONG_BOTH         = ("invalid_user_abc", "invalid_pass_abc")
SQL_INJECTION_USER = "' OR '1'='1"
SQL_INJECTION_PASS = "' OR '1'='1"
XSS_PAYLOAD        = "<script>alert('xss')</script>"
LONG_USERNAME      = "a" * 300
SPACE_USERNAME     = "   "
SPACE_PASSWORD     = "   "
