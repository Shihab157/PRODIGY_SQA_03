# =============================================================
# utils/login_page.py — Page Object Model for DemoBlaze Login
# =============================================================

import time
import logging
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import (
    TimeoutException,
    NoAlertPresentException,
    UnexpectedAlertPresentException,
    NoSuchElementException
)

logger = logging.getLogger(__name__)


class LoginPage:
    """
    Page Object Model for DemoBlaze login functionality.
    Encapsulates all selectors and interaction methods.
    """

    # ── Locators ──────────────────────────────────────────────
    LOGIN_NAV_LINK   = (By.ID, "login2")
    LOGIN_MODAL      = (By.ID, "logInModal")
    USERNAME_FIELD   = (By.ID, "loginusername")
    PASSWORD_FIELD   = (By.ID, "loginpassword")
    LOGIN_BUTTON     = (By.XPATH, "//button[text()='Log in']")
    CLOSE_BUTTON     = (By.XPATH, "//div[@id='logInModal']//button[@class='close']")
    WELCOME_NAV      = (By.ID, "nameofuser")
    LOGOUT_LINK      = (By.ID, "logout2")
    NAVBAR           = (By.CLASS_NAME, "navbar-nav")

    MODAL_VISIBLE_CLASS = "show"
    DEFAULT_WAIT = 10

    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(driver, self.DEFAULT_WAIT)

    # ── Navigation ─────────────────────────────────────────────

    def open(self, url: str):
        """Navigate to the base URL."""
        logger.info(f"Opening URL: {url}")
        self.driver.get(url)
        time.sleep(1)

    def click_login_nav(self):
        """Click the 'Log in' link in the navbar to open the modal."""
        logger.info("Clicking 'Log in' in navbar")
        link = self.wait.until(EC.element_to_be_clickable(self.LOGIN_NAV_LINK))
        link.click()
        self._wait_for_modal()

    def _wait_for_modal(self):
        """Wait until the login modal is visible."""
        self.wait.until(
            EC.visibility_of_element_located(self.LOGIN_MODAL)
        )
        time.sleep(0.5)   # allow Bootstrap animation to complete

    # ── Field Interactions ─────────────────────────────────────

    def enter_username(self, username: str):
        field = self.wait.until(EC.visibility_of_element_located(self.USERNAME_FIELD))
        field.clear()
        field.send_keys(username)
        logger.info(f"Entered username: '{username}'")

    def enter_password(self, password: str):
        field = self.wait.until(EC.visibility_of_element_located(self.PASSWORD_FIELD))
        field.clear()
        field.send_keys(password)
        logger.info(f"Entered password: '{'*' * len(password)}'")

    def click_login_button(self):
        logger.info("Clicking 'Log in' submit button")
        btn = self.wait.until(EC.element_to_be_clickable(self.LOGIN_BUTTON))
        btn.click()

    def click_close_button(self):
        logger.info("Clicking modal close (×) button")
        btn = self.wait.until(EC.element_to_be_clickable(self.CLOSE_BUTTON))
        btn.click()
        time.sleep(0.5)

    # ── Compound Actions ───────────────────────────────────────

    def login(self, username: str, password: str):
        """Full login flow: open modal → fill fields → submit."""
        self.click_login_nav()
        self.enter_username(username)
        self.enter_password(password)
        self.click_login_button()
        time.sleep(2)

    # ── Result Helpers ─────────────────────────────────────────

    def get_alert_text(self, timeout: int = 5) -> str | None:
        """
        Capture browser alert text if present.
        Returns None if no alert appears within timeout.
        """
        try:
            alert = WebDriverWait(self.driver, timeout).until(EC.alert_is_present())
            text = alert.text
            logger.info(f"Alert detected: '{text}'")
            alert.accept()
            return text
        except TimeoutException:
            return None

    def is_logged_in(self, timeout: int = 5) -> bool:
        """
        Returns True if 'Welcome <username>' appears in the navbar
        after a successful login.
        """
        try:
            el = WebDriverWait(self.driver, timeout).until(
                EC.visibility_of_element_located(self.WELCOME_NAV)
            )
            text = el.text
            logger.info(f"Welcome element text: '{text}'")
            return "Welcome" in text
        except TimeoutException:
            return False

    def is_modal_open(self) -> bool:
        """Returns True if the login modal is currently visible."""
        try:
            modal = self.driver.find_element(*self.LOGIN_MODAL)
            return self.MODAL_VISIBLE_CLASS in modal.get_attribute("class")
        except NoSuchElementException:
            return False

    def is_modal_closed(self, timeout: int = 5) -> bool:
        """Returns True if the login modal has closed."""
        try:
            WebDriverWait(self.driver, timeout).until(
                EC.invisibility_of_element_located(self.LOGIN_MODAL)
            )
            return True
        except TimeoutException:
            return False

    def get_username_field_value(self) -> str:
        """Returns current value inside the username input field."""
        field = self.driver.find_element(*self.USERNAME_FIELD)
        return field.get_attribute("value")

    def get_password_field_value(self) -> str:
        """Returns current value inside the password input field."""
        field = self.driver.find_element(*self.PASSWORD_FIELD)
        return field.get_attribute("value")

    def logout(self):
        """Click logout if logged in."""
        try:
            btn = self.wait.until(EC.element_to_be_clickable(self.LOGOUT_LINK))
            btn.click()
            time.sleep(1)
            logger.info("Logged out successfully")
        except TimeoutException:
            logger.warning("Logout button not found — user may already be logged out")

    def get_page_title(self) -> str:
        return self.driver.title

    def get_current_url(self) -> str:
        return self.driver.current_url
