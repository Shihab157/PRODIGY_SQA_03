# =============================================================
# utils/driver_factory.py — WebDriver setup helper
# =============================================================

from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.firefox.service import Service as FirefoxService
from selenium.webdriver.edge.service import Service as EdgeService
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.firefox.options import Options as FirefoxOptions
from selenium.webdriver.edge.options import Options as EdgeOptions

try:
    from webdriver_manager.chrome import ChromeDriverManager
    from webdriver_manager.firefox import GeckoDriverManager
    from webdriver_manager.microsoft import EdgeChromiumDriverManager
    WDM_AVAILABLE = True
except ImportError:
    WDM_AVAILABLE = False

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import config


def get_driver():
    """
    Returns a configured WebDriver instance based on config.BROWSER.
    Automatically downloads the correct driver binary via webdriver-manager.
    """
    browser = config.BROWSER.lower()

    if browser == "chrome":
        options = ChromeOptions()
        if config.HEADLESS:
            options.add_argument("--headless=new")
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--disable-gpu")
        options.add_argument("--window-size=1920,1080")
        options.add_argument("--disable-extensions")
        options.add_experimental_option("excludeSwitches", ["enable-logging"])

        if WDM_AVAILABLE:
            driver = webdriver.Chrome(
                service=ChromeService(ChromeDriverManager().install()),
                options=options
            )
        else:
            driver = webdriver.Chrome(options=options)

    elif browser == "firefox":
        options = FirefoxOptions()
        if config.HEADLESS:
            options.add_argument("--headless")
        if WDM_AVAILABLE:
            driver = webdriver.Firefox(
                service=FirefoxService(GeckoDriverManager().install()),
                options=options
            )
        else:
            driver = webdriver.Firefox(options=options)

    elif browser == "edge":
        options = EdgeOptions()
        if config.HEADLESS:
            options.add_argument("--headless=new")
        if WDM_AVAILABLE:
            driver = webdriver.Edge(
                service=EdgeService(EdgeChromiumDriverManager().install()),
                options=options
            )
        else:
            driver = webdriver.Edge(options=options)

    else:
        raise ValueError(f"Unsupported browser: '{browser}'. Choose chrome, firefox, or edge.")

    driver.implicitly_wait(config.IMPLICIT_WAIT)
    driver.set_page_load_timeout(config.PAGE_LOAD_TIMEOUT)
    driver.maximize_window()
    return driver
