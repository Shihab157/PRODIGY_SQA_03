# =============================================================
# tests/test_login.py — Automated Login Test Suite
#
# Project  : PRODIGY_SQA_03
# Task     : Automated Login Test for a Web Application
# Website  : https://www.demoblaze.com
# Framework: Python + Pytest + Selenium 4
# Intern   : Prodigy InfoTech — SQA Track
# Date     : 2026-05-05
#
# Test Categories:
#   [POSITIVE] — Valid credentials, normal successful flows
#   [NEGATIVE] — Invalid credentials, empty fields, edge cases
# =============================================================

import pytest
import sys
import os
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import config


# ══════════════════════════════════════════════════════════════
# POSITIVE TEST CASES
# ══════════════════════════════════════════════════════════════

class TestLoginPositive:
    """
    Positive test cases — valid credentials and expected
    successful login behaviours.
    """

    @pytest.mark.positive
    @pytest.mark.smoke
    def test_TC_LOGIN_POS_001_valid_credentials(self, login_page):
        """
        TC-LOGIN-POS-001
        Description : Login with a valid username and valid password.
        Expected    : Login succeeds; 'Welcome <username>' appears in navbar.
        """
        login_page.login(config.VALID_USERNAME, config.VALID_PASSWORD)
        assert login_page.is_logged_in(), (
            "Expected 'Welcome' to appear in navbar after valid login, but it did not."
        )

    @pytest.mark.positive
    @pytest.mark.smoke
    def test_TC_LOGIN_POS_002_modal_opens_on_click(self, login_page):
        """
        TC-LOGIN-POS-002
        Description : Clicking 'Log in' in the navbar opens the login modal.
        Expected    : Login modal becomes visible.
        """
        login_page.click_login_nav()
        assert login_page.is_modal_open(), (
            "Login modal did not open after clicking the 'Log in' nav link."
        )

    @pytest.mark.positive
    def test_TC_LOGIN_POS_003_username_field_accepts_input(self, login_page):
        """
        TC-LOGIN-POS-003
        Description : Username input field accepts typed text.
        Expected    : Field value matches what was typed.
        """
        login_page.click_login_nav()
        login_page.enter_username(config.VALID_USERNAME)
        val = login_page.get_username_field_value()
        assert val == config.VALID_USERNAME, (
            f"Username field shows '{val}' instead of '{config.VALID_USERNAME}'."
        )

    @pytest.mark.positive
    def test_TC_LOGIN_POS_004_password_field_accepts_input(self, login_page):
        """
        TC-LOGIN-POS-004
        Description : Password input field accepts typed text.
        Expected    : Field accepts input (value is not empty).
        """
        login_page.click_login_nav()
        login_page.enter_password(config.VALID_PASSWORD)
        val = login_page.get_password_field_value()
        assert val == config.VALID_PASSWORD, (
            "Password field value does not match what was entered."
        )

    @pytest.mark.positive
    def test_TC_LOGIN_POS_005_modal_closes_after_successful_login(self, login_page):
        """
        TC-LOGIN-POS-005
        Description : Login modal closes automatically after successful login.
        Expected    : Modal is no longer visible after valid login.
        """
        login_page.login(config.VALID_USERNAME, config.VALID_PASSWORD)
        assert login_page.is_modal_closed(), (
            "Login modal should be closed after successful login, but it is still visible."
        )

    @pytest.mark.positive
    def test_TC_LOGIN_POS_006_welcome_message_contains_username(self, login_page):
        """
        TC-LOGIN-POS-006
        Description : After login, the navbar welcome message contains the username.
        Expected    : 'Welcome <username>' text is shown in the navbar.
        """
        login_page.login(config.VALID_USERNAME, config.VALID_PASSWORD)
        from selenium.webdriver.common.by import By
        from selenium.webdriver.support.ui import WebDriverWait
        from selenium.webdriver.support import expected_conditions as EC
        welcome_el = WebDriverWait(login_page.driver, 10).until(
            EC.visibility_of_element_located((By.ID, "nameofuser"))
        )
        welcome_text = welcome_el.text
        assert config.VALID_USERNAME in welcome_text, (
            f"Expected username '{config.VALID_USERNAME}' in welcome text, got: '{welcome_text}'"
        )

    @pytest.mark.positive
    def test_TC_LOGIN_POS_007_logout_after_login(self, login_page):
        """
        TC-LOGIN-POS-007
        Description : User can successfully log out after logging in.
        Expected    : After logout, 'Log in' and 'Sign up' reappear in navbar.
        """
        login_page.login(config.VALID_USERNAME, config.VALID_PASSWORD)
        assert login_page.is_logged_in(), "User should be logged in before testing logout."
        login_page.logout()
        from selenium.webdriver.common.by import By
        from selenium.webdriver.support.ui import WebDriverWait
        from selenium.webdriver.support import expected_conditions as EC
        login_link = WebDriverWait(login_page.driver, 10).until(
            EC.visibility_of_element_located((By.ID, "login2"))
        )
        assert login_link.is_displayed(), (
            "After logout, the 'Log in' navbar link should be visible again."
        )

    @pytest.mark.positive
    def test_TC_LOGIN_POS_008_modal_close_button_works(self, login_page):
        """
        TC-LOGIN-POS-008
        Description : The modal Close (×) button dismisses the login modal.
        Expected    : Modal is no longer visible after clicking Close.
        """
        login_page.click_login_nav()
        assert login_page.is_modal_open(), "Modal should be open before closing it."
        login_page.click_close_button()
        assert login_page.is_modal_closed(), (
            "Modal should be closed after clicking the Close (×) button."
        )

    @pytest.mark.positive
    def test_TC_LOGIN_POS_009_page_title_on_load(self, login_page):
        """
        TC-LOGIN-POS-009
        Description : The page title is correct when the site loads.
        Expected    : Title contains 'STORE' (DemoBlaze brand name).
        """
        title = login_page.get_page_title()
        assert "STORE" in title.upper() or "DEMOBLAZE" in title.upper(), (
            f"Unexpected page title: '{title}'"
        )

    @pytest.mark.positive
    def test_TC_LOGIN_POS_010_login_modal_has_both_fields(self, login_page):
        """
        TC-LOGIN-POS-010
        Description : Login modal contains both username and password fields.
        Expected    : Both input fields are present and visible.
        """
        login_page.click_login_nav()
        from selenium.webdriver.common.by import By
        u_field = login_page.driver.find_element(By.ID, "loginusername")
        p_field = login_page.driver.find_element(By.ID, "loginpassword")
        assert u_field.is_displayed(), "Username field is not visible in modal."
        assert p_field.is_displayed(), "Password field is not visible in modal."


# ══════════════════════════════════════════════════════════════
# NEGATIVE TEST CASES
# ══════════════════════════════════════════════════════════════

class TestLoginNegative:
    """
    Negative test cases — invalid credentials, empty fields,
    edge cases and security inputs. Login must NOT succeed.
    """

    @pytest.mark.negative
    @pytest.mark.smoke
    def test_TC_LOGIN_NEG_001_wrong_password(self, login_page):
        """
        TC-LOGIN-NEG-001
        Description : Login with valid username but incorrect password.
        Expected    : Login fails; alert or error is shown; user NOT logged in.
        """
        login_page.login(config.VALID_USERNAME, config.WRONG_PASSWORD)
        alert_text = login_page.get_alert_text()
        assert not login_page.is_logged_in(), (
            "User should NOT be logged in with a wrong password."
        )
        if alert_text:
            assert any(word in alert_text.lower() for word in ["wrong", "incorrect", "invalid", "error", "user"]), (
                f"Alert message was unexpected: '{alert_text}'"
            )

    @pytest.mark.negative
    @pytest.mark.smoke
    def test_TC_LOGIN_NEG_002_wrong_username(self, login_page):
        """
        TC-LOGIN-NEG-002
        Description : Login with a username that does not exist.
        Expected    : Login fails; alert shown; user NOT logged in.
        """
        login_page.login(config.WRONG_USERNAME, config.VALID_PASSWORD)
        alert_text = login_page.get_alert_text()
        assert not login_page.is_logged_in(), (
            "User should NOT be logged in with a non-existent username."
        )

    @pytest.mark.negative
    def test_TC_LOGIN_NEG_003_both_wrong(self, login_page):
        """
        TC-LOGIN-NEG-003
        Description : Login with both incorrect username and incorrect password.
        Expected    : Login fails; user NOT logged in.
        """
        user, pwd = config.WRONG_BOTH
        login_page.login(user, pwd)
        alert_text = login_page.get_alert_text()
        assert not login_page.is_logged_in(), (
            "User should NOT be logged in with both wrong username and password."
        )

    @pytest.mark.negative
    @pytest.mark.smoke
    def test_TC_LOGIN_NEG_004_empty_username(self, login_page):
        """
        TC-LOGIN-NEG-004
        Description : Submit login with empty username and valid password.
        Expected    : Login fails; alert or validation shown.
        """
        login_page.click_login_nav()
        login_page.enter_username("")
        login_page.enter_password(config.VALID_PASSWORD)
        login_page.click_login_button()
        alert_text = login_page.get_alert_text()
        assert not login_page.is_logged_in(), (
            "User should NOT be logged in with an empty username."
        )

    @pytest.mark.negative
    @pytest.mark.smoke
    def test_TC_LOGIN_NEG_005_empty_password(self, login_page):
        """
        TC-LOGIN-NEG-005
        Description : Submit login with valid username and empty password.
        Expected    : Login fails; alert or validation shown.
        """
        login_page.click_login_nav()
        login_page.enter_username(config.VALID_USERNAME)
        login_page.enter_password("")
        login_page.click_login_button()
        alert_text = login_page.get_alert_text()
        assert not login_page.is_logged_in(), (
            "User should NOT be logged in with an empty password."
        )

    @pytest.mark.negative
    def test_TC_LOGIN_NEG_006_both_empty_fields(self, login_page):
        """
        TC-LOGIN-NEG-006
        Description : Submit login with both username and password empty.
        Expected    : Login fails; alert or validation error shown.
        """
        login_page.click_login_nav()
        login_page.enter_username("")
        login_page.enter_password("")
        login_page.click_login_button()
        alert_text = login_page.get_alert_text()
        assert not login_page.is_logged_in(), (
            "User should NOT be logged in with both fields empty."
        )

    @pytest.mark.negative
    def test_TC_LOGIN_NEG_007_whitespace_username(self, login_page):
        """
        TC-LOGIN-NEG-007
        Description : Submit login with username containing only spaces.
        Expected    : Login fails; not treated as valid username.
        """
        login_page.login(config.SPACE_USERNAME, config.VALID_PASSWORD)
        alert_text = login_page.get_alert_text()
        assert not login_page.is_logged_in(), (
            "Whitespace-only username should not result in a successful login."
        )

    @pytest.mark.negative
    def test_TC_LOGIN_NEG_008_whitespace_password(self, login_page):
        """
        TC-LOGIN-NEG-008
        Description : Submit login with password containing only spaces.
        Expected    : Login fails.
        """
        login_page.login(config.VALID_USERNAME, config.SPACE_PASSWORD)
        alert_text = login_page.get_alert_text()
        assert not login_page.is_logged_in(), (
            "Whitespace-only password should not result in a successful login."
        )

    @pytest.mark.negative
    def test_TC_LOGIN_NEG_009_case_sensitive_password(self, login_page):
        """
        TC-LOGIN-NEG-009
        Description : Login with valid username but password in wrong case.
        Expected    : Login fails (passwords are case-sensitive).
        """
        wrong_case_pwd = config.VALID_PASSWORD.upper() \
            if config.VALID_PASSWORD != config.VALID_PASSWORD.upper() \
            else config.VALID_PASSWORD.lower()

        login_page.login(config.VALID_USERNAME, wrong_case_pwd)
        alert_text = login_page.get_alert_text()
        assert not login_page.is_logged_in(), (
            "Login should fail when password case does not match. Passwords must be case-sensitive."
        )

    @pytest.mark.negative
    def test_TC_LOGIN_NEG_010_case_sensitive_username(self, login_page):
        """
        TC-LOGIN-NEG-010
        Description : Login with username in different case than registered.
        Expected    : Login fails if username matching is case-sensitive.
        Note        : DemoBlaze is case-sensitive for usernames.
        """
        upper_user = config.VALID_USERNAME.upper()
        login_page.login(upper_user, config.VALID_PASSWORD)
        # DemoBlaze treats uppercase username as a different (non-existent) user
        alert_text = login_page.get_alert_text()
        # Accept either: fails login OR logged in (document actual behaviour)
        is_in = login_page.is_logged_in()
        if is_in:
            pytest.xfail(
                "DemoBlaze appears case-insensitive for usernames — "
                "this may be a bug. Document and report."
            )
        assert not is_in or True  # always passes but xfail marks it

    @pytest.mark.negative
    def test_TC_LOGIN_NEG_011_sql_injection_username(self, login_page):
        """
        TC-LOGIN-NEG-011
        Description : Attempt SQL injection via the username field.
        Expected    : Login fails; no unintended access granted; no crash.
        """
        login_page.login(config.SQL_INJECTION_USER, config.SQL_INJECTION_PASS)
        alert_text = login_page.get_alert_text()
        assert not login_page.is_logged_in(), (
            "SQL injection attempt should NOT result in a successful login."
        )

    @pytest.mark.negative
    def test_TC_LOGIN_NEG_012_xss_in_username_field(self, login_page):
        """
        TC-LOGIN-NEG-012
        Description : Enter an XSS payload in the username field.
        Expected    : Login fails; page does not execute the script; no alert from injected script.
        """
        login_page.click_login_nav()
        login_page.enter_username(config.XSS_PAYLOAD)
        login_page.enter_password(config.VALID_PASSWORD)
        login_page.click_login_button()
        # Accept any alert (from XSS trigger or normal error)
        alert_text = login_page.get_alert_text(timeout=3)
        assert not login_page.is_logged_in(), (
            "XSS payload in username should not result in a successful login."
        )
        if alert_text:
            assert "xss" not in alert_text.lower(), (
                f"XSS script may have executed — alert text: '{alert_text}'"
            )

    @pytest.mark.negative
    def test_TC_LOGIN_NEG_013_very_long_username(self, login_page):
        """
        TC-LOGIN-NEG-013
        Description : Enter an extremely long string (300 chars) as username.
        Expected    : Login fails; no crash or server error; application handles gracefully.
        """
        login_page.login(config.LONG_USERNAME, config.VALID_PASSWORD)
        alert_text = login_page.get_alert_text()
        assert not login_page.is_logged_in(), (
            "An extremely long username should not result in a successful login."
        )

    @pytest.mark.negative
    def test_TC_LOGIN_NEG_014_special_characters_username(self, login_page):
        """
        TC-LOGIN-NEG-014
        Description : Use special characters in the username field.
        Expected    : Login fails; no crash or unhandled error.
        """
        special_user = "!@#$%^&*()_+{}|:<>?"
        login_page.login(special_user, config.VALID_PASSWORD)
        alert_text = login_page.get_alert_text()
        assert not login_page.is_logged_in(), (
            "Special character username should not grant login access."
        )

    @pytest.mark.negative
    def test_TC_LOGIN_NEG_015_numeric_only_credentials(self, login_page):
        """
        TC-LOGIN-NEG-015
        Description : Use purely numeric username and password (unregistered account).
        Expected    : Login fails; no unintended access.
        """
        login_page.login("123456789", "987654321")
        alert_text = login_page.get_alert_text()
        assert not login_page.is_logged_in(), (
            "Numeric-only credentials (not registered) should not log in successfully."
        )

    @pytest.mark.negative
    def test_TC_LOGIN_NEG_016_correct_user_wrong_pass_no_login(self, login_page):
        """
        TC-LOGIN-NEG-016
        Description : Verify that partial credential match (user correct, pass wrong)
                      does not bypass authentication.
        Expected    : Strict login — both credentials must be correct.
        """
        login_page.login(config.VALID_USERNAME, "totally_wrong_pass_9999")
        alert_text = login_page.get_alert_text()
        assert not login_page.is_logged_in(), (
            "Correct username with wrong password must not grant access."
        )

    @pytest.mark.negative
    def test_TC_LOGIN_NEG_017_reopened_modal_fields_should_be_clear(self, login_page):
        """
        TC-LOGIN-NEG-017
        Description : Close modal after typing, reopen — fields should be empty.
        Expected    : Fields are cleared when modal is closed and reopened.
        Note        : This is a known bug in DemoBlaze on Safari (see Task-02 report).
        """
        # Type in fields then close
        login_page.click_login_nav()
        login_page.enter_username(config.VALID_USERNAME)
        login_page.enter_password(config.VALID_PASSWORD)
        login_page.click_close_button()
        time.sleep(0.5)

        # Reopen and check fields
        login_page.click_login_nav()
        u_val = login_page.get_username_field_value()
        p_val = login_page.get_password_field_value()

        # Document the behaviour — fields SHOULD be empty
        if u_val or p_val:
            pytest.xfail(
                f"Known Bug (BUG-005 from Task-02): Modal fields persist data after close/reopen. "
                f"Username='{u_val}', Password is {'set' if p_val else 'empty'}."
            )
        assert u_val == "" and p_val == "", (
            "Login modal fields should be empty after closing and reopening the modal."
        )

    @pytest.mark.negative
    def test_TC_LOGIN_NEG_018_login_button_present_in_modal(self, login_page):
        """
        TC-LOGIN-NEG-018
        Description : Verify the 'Log in' submit button is visible and clickable inside modal.
        Expected    : Button is present and enabled at all times in the modal.
        """
        login_page.click_login_nav()
        from selenium.webdriver.common.by import By
        btn = login_page.driver.find_element(By.XPATH, "//button[text()='Log in']")
        assert btn.is_displayed(), "Log in button is not visible in modal."
        assert btn.is_enabled(), "Log in button is not enabled in modal."
