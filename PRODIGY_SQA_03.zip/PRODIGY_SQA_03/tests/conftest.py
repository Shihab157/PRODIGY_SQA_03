# =============================================================
# tests/conftest.py — Shared fixtures for pytest
# =============================================================

import pytest
import sys
import os
import logging

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import config
from utils.driver_factory import get_driver
from utils.login_page import LoginPage

logger = logging.getLogger(__name__)


@pytest.fixture(scope="function")
def driver():
    """
    Provides a fresh WebDriver instance for each test function.
    Quits the browser after each test automatically.
    """
    drv = get_driver()
    logger.info(f"Browser launched: {config.BROWSER}")
    yield drv
    drv.quit()
    logger.info("Browser closed")


@pytest.fixture(scope="function")
def login_page(driver):
    """
    Provides a LoginPage object with the browser already navigated
    to the DemoBlaze home page.
    """
    page = LoginPage(driver)
    page.open(config.BASE_URL)
    return page


@pytest.fixture(scope="function")
def logged_in_page(login_page):
    """
    Provides a LoginPage object where the user is already logged in
    with valid credentials. Used for post-login test cases.
    """
    login_page.login(config.VALID_USERNAME, config.VALID_PASSWORD)
    return login_page


def pytest_html_report_title(report):
    report.title = "PRODIGY_SQA_03 — Automated Login Test Report"


def pytest_configure(config_obj):
    config_obj.addinivalue_line(
        "markers", "positive: Positive login test cases"
    )
    config_obj.addinivalue_line(
        "markers", "negative: Negative login test cases"
    )
    config_obj.addinivalue_line(
        "markers", "smoke: Basic smoke tests"
    )
